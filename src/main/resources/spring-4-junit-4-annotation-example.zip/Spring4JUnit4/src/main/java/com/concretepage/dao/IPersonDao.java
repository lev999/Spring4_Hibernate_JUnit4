package com.concretepage.dao;


public interface IPersonDao {
  public void savePerson();
}
